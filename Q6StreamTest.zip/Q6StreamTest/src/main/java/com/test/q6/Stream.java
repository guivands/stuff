package com.test.q6;

public interface Stream {
	public char getNext();
	public boolean hasNext();
}
