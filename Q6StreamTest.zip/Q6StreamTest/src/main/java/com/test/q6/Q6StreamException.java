package com.test.q6;

/**
 * Exception utilizada para casos onde a vogal da questao nao e encontrada
 * @author Guilherme Gomes
 *
 */
public class Q6StreamException extends RuntimeException {

	public Q6StreamException(String message) {
		super(message);
	}

}
