package com.test.q6;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Quest�o 6:
 * Dada uma stream, encontre o primeiro caracter Vogal, ap�s uma consoante, onde a mesma � antecessora 
 * a uma vogal e que n�o se repita no resto da stream. O termino da leitura da stream deve ser garantido 
 * atrav�s do m�todo hasNext(), ou seja, retorna falso para o termino da leitura da stream.
 * 
 * @author Guilherme Gomes
 *
 */
public class StreamResolver {
	
	/**
	 * M�todo que resolve a quest�o, caso precise processar at� o fim e valide os casos validos
	 * 
	 * @param stream
	 * @return
	 */
	public static List<Vowel> resolveValid(Stream stream) {
		//Lista que contem sempre os ultimos tres caracteres (somente os necessarios a serem processados)
		List<Character> chars = new ArrayList<Character>();
		
		//Lista que contem as vogais encontradas
		List<Character> vowels = new ArrayList<Character>();
		
		//Casos validos
		List<Vowel> valid = new ArrayList<Vowel>();
		
		long index = 2;
		while(stream.hasNext()) {
			chars.add(stream.getNext());
			// No minimo 3 caracteres devem existir para ser elegivel para a questao
			if (chars.size() < 3)
				continue;
			
			// Se tiver mais de 3 chars, entao remove o mais antigo
			if (chars.size() > 3)
				chars.remove(0);
			
			//Valida se o estado � valido
			if (statePasses(chars, vowels, valid))
				valid.add(new Vowel(chars.get(chars.size() - 1), index));
			
			index++;
		}

		return valid;
	}
	
	/**
	 * M�todo que resolve a quest�o, caso nao precise processar at� o fim e possa parar no primeiro que se enquadre no caso
	 * 
	 * @param stream
	 * @return
	 */
	public static Vowel resolve(Stream stream) {
		//Lista que contem sempre os ultimos tres caracteres (somente os necessarios a serem processados)
		List<Character> chars = new ArrayList<Character>();
		
		//Lista que contem as vogais encontradas
		List<Character> vowels = new ArrayList<Character>();
		
		long index = 2;
		while(stream.hasNext()) {
			chars.add(stream.getNext());
			// No minimo 3 caracteres devem existir para ser elegivel para a questao
			if (chars.size() < 3)
				continue;
			
			// Se tiver mais de 3 chars, entao remove o mais antigo
			if (chars.size() > 3)
				chars.remove(0);
			
			//Valida se o estado � valido
			if (statePasses(chars, vowels, null))
				return new Vowel(chars.get(chars.size() - 1), index);
			
			index++;
		}

		throw new Q6StreamException("Nenhum caracter elegivel na Stream");
	}

	/**
	 * Validador do estado:
	 * <ul>
	 * 	<li>� uma vogal nao repetida?</li>
	 * 	<li>Anterior � uma consoante?</li>
	 * 	<li>Duas casas atras � vogal?</li>
	 * </ul>
	 * @param chars
	 * @param vowels
	 * @return
	 */
	private static boolean statePasses(List<Character> chars, List<Character> vowels , List<Vowel> valid) {
		Character current = Character.toLowerCase(chars.get(2));
		if (!current.toString().matches("[aeiou]"))
			return false;
		
		// Caso precise validar a stream completa, remove os casos que eram v�lidos, mas agora s�o duplicados
		if (valid != null) {
			Iterator<Vowel> iterator = valid.iterator();
			while(iterator.hasNext()) {
				Vowel vowel = iterator.next();
				if (Character.toLowerCase(vowel.getVowel()) == current)
					iterator.remove();
			}
		}

		if (vowels.contains(current))
			return false;
		vowels.add(current);
		
		Character last = Character.toLowerCase(chars.get(1));
		if (!last.toString().matches("[b-df-hj-np-tv-z]"))
			return false;
		
		Character lastM1 = Character.toLowerCase(chars.get(0));
		System.out.println(lastM1 + " - " + last + " - " + current + " = " + (lastM1.toString().matches("[aeiou]")));
		if (!lastM1.toString().matches("[aeiou]"))
			return false;
		
		
		// Se passou em todos os tests, esta validado
		return true;
	}

}
