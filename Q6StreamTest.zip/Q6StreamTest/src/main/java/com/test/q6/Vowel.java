package com.test.q6;

/**
 * POJO utilizado para encapsular a vogal e a posi��o onde se encontra na stream
 * 
 * @author Guilherme Gomes
 *
 */
public class Vowel {
	private Character vowel;
	private Long position;
	
	public Vowel() {}
	
	public Vowel(Character vowel, Long position) {
		this.vowel = vowel;
		this.position = position;
	}

	public Character getVowel() {
		return vowel;
	}
	public void setVowel(Character vowel) {
		this.vowel = vowel;
	}
	public Long getPosition() {
		return position;
	}
	public void setPosition(Long position) {
		this.position = position;
	}

	@Override
	public String toString() {
		return "Vowel [vowel=" + vowel + ", position=" + position + "]";
	}
}
