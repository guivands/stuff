package com.test.q6;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

public class StreamResolverTest {
	
	/**
	 * Testa o cenario simples, onde para ao encontrar um cenario valido
	 */
	@Test
	public void testStream() {
		Stream stream = new StreamTest("aAbBABacafe");
		Vowel vowel = StreamResolver.resolve(stream);

		System.out.println(vowel);
		Assert.assertTrue(vowel.getVowel() == 'e' && vowel.getPosition() == 10);
	}
	
	/**
	 * Testa um cenario onde existem 2 validos
	 */
	@Test
	public void test2Cases() {
		Stream stream = new StreamTest("aAbBABacafedu");
		List<Vowel> vowels = StreamResolver.resolveValid(stream);

		System.out.println(vowels);
		Assert.assertTrue(vowels.size() == 2);
	}
	
	/**
	 * Testa um cenario onde existe 2 validos, onde o segundo deve ser retirado ap�s aparecer a vogal de novo
	 */
	@Test
	public void testCaseRepeatedAfter() {
		Stream stream = new StreamTest("aAbBABacafeduU");
		List<Vowel> vowels = StreamResolver.resolveValid(stream);

		System.out.println(vowels);
		Assert.assertTrue(vowels.size() == 1);
	}
	
	/**
	 * Classe auxiliar para testar o stream com strings
	 * @author Guilherme Gomes
	 *
	 */
	private static class StreamTest implements Stream {
		private String str;
		private Integer index;
		
		public StreamTest(String str) {
			this.str = str;
			this.index = 0;
		}

		public char getNext() {
			return str.charAt(index++);
		}

		public boolean hasNext() {
			return str.length() > index;
		}
		
	}
}
