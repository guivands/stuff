var http = require('http');
var app = require('./config/express');

app.set('view engine', 'ejs');

var cors = require('cors');
//app.use(cors());

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");

  next();
});


app.get('/main2.js', (req, res)=> {
	res.set('Content-Type', 'text/javascript');
	res.render("main2", {phone:req.query.phone});
});

//app.get('/js/mobile-app.js', (req, res)=> {
//	res.set('Content-Type', 'text/javascript');
	//res.render("mobile-app", {phone:req.query.phone});
//});


//Ouvidoria fixa:
app.get('/js/ouvidoria-movel/init.js', (req, res) => {
	res.set('Content-Type', 'text/javascript');
	res.render("ouvidoria-movel", {phone:req.query.phone});
});
app.get('/js/ouvidoria-movel/ua-parse.js', (req, res) => {
	res.set('Content-Type', 'text/javascript');
	res.render("ua-parse-ouvidoria-movel", {phone:req.query.phone});
});
app.get('/js/ouvidoria-movel/main.js', (req, res) => {
	res.set('Content-Type', 'text/javascript');
	res.render("mainouvidoria-movel", {phone:req.query.phone});
});
//Ouvidoria fixa - FIM

http.createServer(app)
.listen(process.env.PORT || 3030, function() {
	console.log('Servidor iniciado DESKTOP 3030');
});

 

//var server = app.listen(process.env.PORT || 3000, process.env.IP || "0.0.0.0", function(){
//  var addr = server.address();
//  logger.info("Servidor iniciado em", addr.address + ":" + addr.port);
//});