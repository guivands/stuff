import datetime
print (datetime.datetime.now().strftime('%Y%m%d%H%M'))
