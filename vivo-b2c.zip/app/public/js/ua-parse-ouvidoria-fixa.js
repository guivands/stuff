(function(){

    
setTimeout(function(){
    var box = document.getElementsByClassName("boxConteudo3");
    var div = document.createElement("div");
    div.innerHTML = "<link href='https://vivo-b2c.mybluemix.net/css/ouvidoria.css' rel='stylesheet'/> </script><div id='vivi-ouvidoria'> <div class='form' style='display: inline-block;'> <input class='input-box' id='texto' type='text' placeholder='Escreva sua pergunta aqui.'> </div> <div class='form' style='display: inline-block;margin-left: -5px;'> <input class='input-button' id='enviar' type='button' value='Pesquisar'>  </div> <div class='flex'> <div class='box-resposta' style='display: none;'> <div class='faixa-vivi'></div><div id='apagar'> <span class='resposta-vivi'> <span> </div> </div> </div></div>";
    document.getElementById("inbenta").appendChild(div);



  // document.getElementsByTagName("body")[0]//.appendChild(div);
   var script = document.createElement('script');
   script.src= 'https://vivo-b2c.mybluemix.net/js/mainouvidoriafixa.js';
   console.log(document.getElementsByTagName('head')[0]);
   document.getElementsByTagName('head')[0].appendChild(script);
   
  


       }, 3000);

       // var script = document.createElement('script');
        //script.src= 'https://code.jquery.com/jquery-1.12.4.js';
        //document.getElementsByTagName('head')[0].appendChild(script);



})();