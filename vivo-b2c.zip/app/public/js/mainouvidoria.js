$(function(){

var pesquisa = "";
var codSend = "";
var parser = new UAParser(); 
var reproduzAudio = false;
var mapActive = true;
var origemRota = "";
var destinoRota = "";
var jsonSatisfacao = "";
var comentario = "";
var evaluation;
var answerSatis;         
var mapSlide = false;
var texto = "";
var context_Returned = "";
var recording = false; // "https://assistentevirtual.mybluemix.net/api/conversations/"+ context_Returned 
var i = 0;
//var context = new AudioContext();// http://pruebaeveris.mybluemix.net/api/conversations
//Ajax
var ajaxURL = "https://eva-broker.mybluemix.net/api/conversations/"+ context_Returned;//"http://localhost:51480/api/mapfre/conversation"; "http://netcorecontroler.mybluemix.net/api/mapfre/conversation"
var ajaxType = "POST";
var ajaxResponseParseMethod = "json";
var ajaxCrossDomain = true;
// 'PROJECT': 'B2C',
       // 'CHANNEL': 'Ouvidoria',
var headersAjax = {
        'Accept': 'application/json',
        'Content-type': 'application/json',
        'PROJECT': 'B2C',
        'CHANNEL': 'Ouvidoria',
        'API-KEY': '56448193-695a-40b4-9ffc-28891a758034',
        'OS': parser.getOS().name,
        'OS-VERSION': parser.getOS().version,
       'BROWSER': parser.getBrowser().name,
        'BROWSER-VERSION': parser.getBrowser().version,
        'LOCALE': 'pt-br',
         'USER-REF': "127.0.0.1",
         'BUSINESS-KEY': ""
        };

        window.mostrarWidgetVivi = function(numwidget) {
           widgettop = numwidget;
           widget = true;
           $('#web').css('top', ""+numwidget+"px").css('display','block');
           
       };
 

  
       $("#enviar").click(function(){

            var text = $('#texto').val();
          
          if ($('#texto').val() != ""){

                    sendMensagemWatson(text);          
              }
  
             // $('#texto').val('');

        });

         $('#texto').keypress(function (event) {
        if (event.which == 13) {
               $("#enviar").click();
                

        }
         });
         
         $(document).keypress(function (event) {
        if (event.which == 13) {
              $("#enviar").click();
                

        }
         });

        

function sendMensagemWatson(usermessage) {

    /* Define estrutura da mensagem para ser enviada via JSON ao servidor */

    var response_Returned = "";
    var dialogStack_Returned = "";
    var dialog_turn_counter_Returned = 0;
    var dialog_request_counter_Returned = 0;

  //  if ($('.scroll-everis').data('context') != null) {
   ////     context_Returned = JSON.stringify($('.scroll-everis').data('context'));
   //}

   ajaxURL = "https://eva-broker.mybluemix.net/api/conversations/"+ context_Returned;
   
    var message = {
        text: usermessage,
        returnAudio: false
    };
     if(codSend)
        message.code = codSend;
  

    /* Define AJAX Settings */
    jQuery.support.cors = true;
    var ajaxDataToTarget = message;  

  
    console.log(message);

    /* Define AJAX Settings */
    jQuery.support.cors = true;
    var ajaxDataToTarget = message;  

    jQuery.ajax({
        
         headers:headersAjax,                     
         type: ajaxType,							 
         url: ajaxURL,									
         crossDomain: ajaxCrossDomain,		    
         data: JSON.stringify(ajaxDataToTarget),	
         dataType: ajaxResponseParseMethod,		
         success:function(data) {
                //console.log(data.sessionCode);
                try{

                    if(data.sessionCode)
                    context_Returned = data.sessionCode;

                  }catch(err){


                  }
                    console.log(data);
                        answerAssistant(data);
              
            },
             error:function(data){
                answerAssistantError();
                console.log(data);
            }
 })
  
  console.log(ajaxURL);
}

     function answerAssistantError(){
        console.log("Error")
     }

  function answerAssistant(texto){
    console.log(texto);
    var span = "";
    $('.box-resposta').css('display','block');
    
       try{
        var html = "<div>";
        for(var i=0; i<texto.answers.length; i++){
                                                   
            html +=" <div class='link' data-element='esconder'><i class='seta-setaouvidoria' aria-hidden='true'style='color: purple;'></i>" + texto.answers[i].title +"</div><div class='esconder' style='display: none;'>  <span class='textvivi'>" + texto.answers[i].text + "</span>  <div class='marca'>" ;
           
          }
          for(var i=0; i<texto.answers[0].options.length; i++){

                 span +="<span class='inline'><p class='in' data-element='"+i+"'><i class='seta-setaouvidoria' aria-hidden='true'style='color: purple;'></i>"+texto.answers[0].options[i].title+"</p> <div id="+i+" class='subline' style='display: none;'>"+ texto.answers[0].options[i].text +"</div></span>"
                  
          }
          console.log(span);
         $(".resposta-vivi").html(html + span+ "</div></div>");
   
       }catch(err){

            span =" <div id="+i+" class='subline' style='display: block;'>"+ texto.answers[0].text +"</div>"
       
            $(".resposta-vivi").html(html);

       }

        $("#texto").attr('placeholder','Escreva uma mensagem')
                           .css('background', 'white')
                              .removeAttr('disabled')
                               .focus();
       
        $("#enviar").removeAttr('disabled');
     

    }
   $(".resposta-vivi").delegate(".link", "click",function(e){

            el = $(this).data('element');
            esconder = "." + el ;
            
           
            var x =   $(esconder).attr("style");
            console.log(x + "ca");

            if(x == 'display: none;'){
                  $(esconder).css('display','block');

            }else{  $(esconder).css('display','none');}
           
           
          
        });


         $(".resposta-vivi").delegate(".in", "click",function(e){

            
            el = $(this).data('element');
            esconder = "#" + el ;
            
           console.log(esconder);
            var x = $(esconder).attr("style");
            console.log(x + "ca");

            if(x == 'display: none;'){
                  $(esconder).css('display','block');

            }else{  $(esconder).css('display','none');}
           
           
          
        });


  

    

       $(".scroll-everis").delegate("#lis-poup", "click",function(){
          
              
                  var title = $(this).data('title');
           
               var top = +  127 + $(this).offset().top;
              

               $('.poup-intent').css('display','block').css('top', top+'px');//scroll-poup
                 console.log("left: " +$(this).offset().left + 'altura: ' +$('.scroll-poup').height());
                    console.log(450 - $('.scroll-poup').height());

               $('.scroll-poup').html($(this).data('text'));

        $(".icon-x").click(function(){   
                 $('.poup-intent').css('display', 'none');
            });
                 
                 $('#poupchat').draggable({ axis: "x", cancel: "div.poup-intent"});
                 });

      $('.top-seta-1').click(function(){

              $('#poupchat').css('display','none');
              $('.assistent').css('display','block').css('opacity','1');
              $('.satisfacao').css('display','block').animate({top: '80px', left: "20%"});
            


      });  

      $('.top-seta').click(function(){
             $('#poupchat').css('display','none');
               $('.assistent').animate({opacity: '1'}, 280).css('display','block');


          });  

          $('.assistent').click(function(){
              $(this).animate({opacity: '0'}, 280).css('opacity','0');
              $('#poupchat').css('display','block');
             


          });  
           
           // fechar satisfação
         $('.icon-satis').click(function(){
                   $('.satisfacao').css('display','none').css('top','0px');
                       $('#satisfacao').css('display','block');
                        $('#feedback-satisfacao').css('display','none');
                            $('.assistent').animate({opacity: '1'}, 280).css('display','block');
                        
            
        
             });
       
             // passo seguinte da satisfação
        //  $('#button-satisfacao').click(function(){
           
//$('#feedback-satisfacao').css('display','block');
           //   $('#satisfacao').css('display','none');


        //  }); 
           $('#button-satisfacao-atras').click(function(){
           
             $('#feedback-satisfacao').css('display','none');
              $('#satisfacao').css('display','block');


          }); 

          $('#satisfacao').delegate(".button-satisfacao", "click",function(){

                console.log($("input[name='satisf']:checked").val());
                console.log($("input[name='seguin']:checked").val());

                if ($("input[name='seguin']:checked").val() == "NAO"){

                         
                    $('#feedback-satisfacao').css('display','block');
                    $('#satisfacao').css('display','none');
                      $('.assistent').animate({opacity: '1'}, 280).css('display','block');
                      evaluation =  $('input[name="satisf"]:checked').val();
                      answerSatis = false;
                 
                    
                }else{

                     jsonSatisfacao = {
                        evaluation:  $('input[name="satisf"]:checked').val(),
                        answered: true,
                        userComments: "" };

                      PesquisaSatisfacao(jsonSatisfacao);

                     $('.satisfacao').css('display','none');
                }

          });

            $('#feedback-satisfacao').delegate("#button-satisfacao-enviar", "click",function(){

                 jsonSatisfacao = {
                        evaluation: evaluation,
                        answered: answerSatis,
                        userComments: $('.texto-area-satisfacao').val()
                     };
                      

                      PesquisaSatisfacao(jsonSatisfacao);
                      $('.satisfacao').css('display','none');
                      $('.texto-area-satisfacao').val(" ");
                      
            });

          function PesquisaSatisfacao(pesquisa){


     jQuery.ajax({
        
         headers:headersAjax,                     
         type: ajaxType	,							 
         url: ajaxURL +  "/satisfactions",									
         crossDomain: ajaxCrossDomain,		    
         data: JSON.stringify(pesquisa),	
         dataType: ajaxResponseParseMethod,		
         success:function(data) {
         console.log(data);

           // answerAssistant(data);
           // if (data.output.mapa.activeMap == true){
             //   Mapa(data.output.mapa.origem, data.output.mapa.destino);
             //    $('#texto').html("<div class='chat-message row'><div class='message-logo col-xs-1 col-md-4 col-sm-2'><img class='img-logo' src='img/logoChat.png'></div><div class='message col-xs-12 col-sm-10 col-md-8'><span> " + data.output.mapa.origem + " " + data.output.mapa.destino + " </span></div></div>");
          //  }

            //Gravar ID da conversa
            context_Returned = data.sessionCode;
    },						        /* true - will cache URL data returned; false - will not cache URL data but only for HEAD AND GET requests */
    error:function(data){
       //  answerAssistantError();
        console.log(data);
    }
 })


          }

          
});
